 List<String> myCategoriesIcons = [
    'car',
    'dinner',
    'first-aid-kit',
    'games',
    'gift',
    'graduation',
    'mortgage-loan',
    'shopping-cart',
    'tools',
    'travel-and-tourism',
  ];